package se.lexicon.course_manager_assignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseManagerAssignmentApplicationTests {

    @Test
    void contextLoads() {
    }

}
