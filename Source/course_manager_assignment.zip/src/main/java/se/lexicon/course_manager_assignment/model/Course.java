package se.lexicon.course_manager_assignment.model;

public class Course {

}
