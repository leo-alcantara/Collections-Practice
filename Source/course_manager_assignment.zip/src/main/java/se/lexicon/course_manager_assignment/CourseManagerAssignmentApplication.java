package se.lexicon.course_manager_assignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseManagerAssignmentApplication {

    public static void main(String[] args) {
        SpringApplication.run(CourseManagerAssignmentApplication.class, args);
    }

}
